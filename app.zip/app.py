from flask import Flask, request, render_template_string
import re
from textwrap import indent
import json

app = Flask(__name__)

# ---- TEMPLATE: note use of source_text (not 'source') ----
TEMPLATE = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>LocalLang Mini — Translator & Runner</title>
</head>
<body>
<h2>Local-language → Python (mini)</h2>
<form method="post">
  <label for="source">Paste local-language source:</label><br>
  <textarea name="source" rows="12" cols="80" placeholder="( x soman 4 ni) holi { ... }">{{ source_text }}</textarea><br><br>
  <button type="submit">Translate & Run</button>
</form>

{% if translated %}
<hr>
<h3>Translated Python</h3>
<pre style="background:#f5f5f5;padding:10px;">{{ translated }}</pre>

<h3>Execution Result</h3>
{% if error %}
  <div style="color:darkred;"><strong>Error during execution:</strong> {{ error }}</div>
  <pre>{{ env }}</pre>
{% else %}
  <div><strong>Final variable values:</strong></div>
  <pre>{{ env }}</pre>
{% endif %}
{% endif %}

<hr>
<h4>Sample inputs you can try</h4>
<pre>
( x soman 4 ni) holi {
    x the 5 bad dao;
    y the 3 jug dao;
    x the y gun dao;
    i er man 1 barai dao;
}
na holi {
    x soman i rakho;
}
</pre>
</body>
</html>
"""

# ---- Translator (simple regex-based rules) ----
def translate_local_to_python(src: str) -> str:
    src = src.strip()
    # if-else pattern
    m = re.search(
        r'\(\s*(\w+)\s+soman\s+(\w+)\s+ni\s*\)\s*holi\s*{(.*?)}\s*na\s+holi\s*{(.*?)}',
        src,
        flags=re.DOTALL
    )

    def translate_stmt(stmt: str) -> str:
        s = stmt.strip()
        if not s:
            return ""
        # addition: bad / jug
        m_add = re.match(r'(\w+)\s+the\s+(\w+)\s+(bad|jug)\s+dao', s)
        if m_add:
            var, val, _ = m_add.groups()
            return f"{var} = {var} + {val}"
        # subtraction: kom
        m_sub = re.match(r'(\w+)\s+the\s+(\w+)\s+kom\s+dao', s)
        if m_sub:
            var, val = m_sub.groups()
            return f"{var} = {var} - {val}"
        # multiplication: gun
        m_mul = re.match(r'(\w+)\s+the\s+(\w+)\s+gun\s+dao', s)
        if m_mul:
            var, val = m_mul.groups()
            return f"{var} = {var} * {val}"
        # division: vag
        m_div = re.match(r'(\w+)\s+the\s+(\w+)\s+vag\s+dao', s)
        if m_div:
            var, val = m_div.groups()
            return f"{var} = {var} / {val}"
        # increment: er man N barai dao
        m_inc = re.match(r'(\w+)\s+er\s+man\s+(\d+)\s+barai\s+dao', s)
        if m_inc:
            var, num = m_inc.groups()
            return f"{var} += {num}"
        # assign: var soman expr rakho
        m_asg = re.match(r'(\w+)\s+soman\s+(\w+)\s+rakho', s)
        if m_asg:
            var, expr = m_asg.groups()
            return f"{var} = {expr}"
        # fallback
        return f"# TODO: unrecognized statement: {s}"

    def translate_block(block_text: str) -> str:
        parts = [p.strip() for p in block_text.split(';') if p.strip()]
        stmts = [translate_stmt(p) for p in parts]
        stmts = [s for s in stmts if s != ""]
        return "\n".join(stmts) or "pass"

    if m:
        cond_var, cond_val, if_body, else_body = m.groups()
        py_if = translate_block(if_body)
        py_else = translate_block(else_body)
        python_code = []
        python_code.append(f"if {cond_var} == {cond_val}:")
        python_code.append(indent(py_if, "    "))
        python_code.append("else:")
        python_code.append(indent(py_else, "    "))
        return "\n".join(python_code)
    else:
        parts = [p.strip() for p in src.split(';') if p.strip()]
        stmts = [translate_stmt(p) for p in parts]
        stmts = [s for s in stmts if s != ""]
        return "\n".join(stmts) or "# empty or unsupported source"

# ---- Execution helper (initializes vars to 0 so += works) ----
def collect_variable_names(py_code: str):
    names = set(re.findall(r'\b([a-zA-Z_]\w*)\b', py_code))
    keywords = {'if', 'else', 'pass'}
    return sorted(names - keywords)

def run_translated_code(py_code: str):
    vars_used = collect_variable_names(py_code)
    env = {}
    for name in vars_used:
        if re.match(r'^\d+$', name):
            continue
        env[name] = 0
    try:
        # Execute with empty globals and env as locals
        exec(py_code, {}, env)
    except Exception as e:
        return {"__error__": str(e), "__env__": env}
    return {"__env__": env}

# ---- Flask route ----
@app.route('/', methods=['GET', 'POST'])
def index():
    translated = None
    exec_res = None
    error = None
    source = ""
    if request.method == 'POST':
        source = request.form.get('source', '').strip()
        translated = translate_local_to_python(source)
        exec_res = run_translated_code(translated)
        if "__error__" in exec_res:
            error = exec_res["__error__"]
            env = exec_res["__env__"]
        else:
            env = exec_res["__env__"]
        env_str = json.dumps(env, indent=2)
        # pass 'source_text' (not 'source') to avoid argument name conflict
        return render_template_string(
            TEMPLATE,
            source_text=source,
            translated=translated,
            error=error,
            env=env_str
        )
    # GET request shows empty textarea
    return render_template_string(TEMPLATE, source_text="")

if __name__ == '__main__':
    # Run dev server on localhost
    app.run(debug=True)
